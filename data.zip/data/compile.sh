exec bash -x compile0.sh "$@"
