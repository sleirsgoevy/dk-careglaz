src="$1"
dst="$2"

if [ "$3" == cpp ]
then
    echo sandbox/run-sandbox "$dst"
    exec >&2
    if [ "x$(which proot)" != x ]
    then
        tmp="$(mktemp -d)"
        cp "$src" "$tmp/src.cpp"
        proot -b "$tmp:." g++ --std=c++14 src.cpp -o a.out -static
        ans="$?"
        cp "$tmp/a.out" "$dst" 2>/dev/null
        rm -r "$tmp"
        exit "$ans"
    else exec g++ --std=c++14 -x c++ "$src" -o "$dst" -static
    fi
elif [ "$3" == pas ]
then
    echo sandbox/run-sandbox "$dst"
    exec >&2
    tmp="$(mktemp -d)"
    if [ "x$(which proot)" != x ]
    then
        cp "$src" "$tmp/src.pas"
        proot -b "$tmp:." fpc -Fotmp.o -oa.out src.pas
        ans="$?"
        cp "$tmp/a.out" "$dst" 2>/dev/null
        rm -r "$tmp"
        exit "$ans"
    else
        fpc -Fo"$tmp"/tmp.o -o"$dst" "$src"
        ans="$?"
        rm -rf "$tmp"
        exit "$ans"
    fi
fi

echo "Unknown extension: $3" >&2
exit 1
